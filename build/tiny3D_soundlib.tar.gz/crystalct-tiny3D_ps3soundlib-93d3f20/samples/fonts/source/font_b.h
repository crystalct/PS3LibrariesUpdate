#define size_font_b 28672

extern unsigned char font_b[28672];
