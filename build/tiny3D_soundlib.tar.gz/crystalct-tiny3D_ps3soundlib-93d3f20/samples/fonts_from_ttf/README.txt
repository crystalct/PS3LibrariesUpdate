NOTE: fonts_from_ttf requires Oopo ps3libraries libz and freetype. You can download

from here: http://mods.elotrolado.net/~hermes/ps3/ps3dev/ppu_oopo-ps3libraries.rar
